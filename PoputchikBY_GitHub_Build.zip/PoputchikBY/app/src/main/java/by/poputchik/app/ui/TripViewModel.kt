package by.poputchik.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import by.poputchik.app.data.Trip
import by.poputchik.app.data.TripDao
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TripViewModel(private val dao: TripDao) : ViewModel() {
    val from = MutableStateFlow("")
    val to = MutableStateFlow("")
    val passengers = MutableStateFlow(1)
    val allTrips = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val results = combine(allTrips, from, to, passengers) { trips, f, t, p ->
        trips.filter {
            (f.isBlank() || it.fromCity.contains(f, true)) &&
            (t.isBlank() || it.toCity.contains(t, true)) &&
            it.seats >= p
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun publish(trip: Trip) {
        viewModelScope.launch { dao.insert(trip) }
    }

    fun delete(id: Long) {
        viewModelScope.launch { dao.delete(id) }
    }
}

class TripViewModelFactory(private val dao: TripDao) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TripViewModel::class.java)) {
            return TripViewModel(dao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel")
    }
}
