package by.poputchik.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trips")
data class Trip(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fromCity: String,
    val toCity: String,
    val date: String,
    val time: String,
    val price: Int,
    val seats: Int,
    val driver: String,
    val car: String,
    val note: String = ""
)
