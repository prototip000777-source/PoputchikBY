package by.poputchik.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import by.poputchik.app.data.Trip
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val cities = listOf(
    "Варшава", "Бяла-Подляска", "Тересполь",
    "Брест", "Минск", "Могилёв", "Глубокое"
)

@Composable
fun PoputchikApp(vm: TripViewModel) {
    var tab by remember { mutableStateOf(0) }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Search, null) }, label = { Text("Найти") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.Add, null) }, label = { Text("Опубликовать") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("Мои поездки") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 },
                    icon = { Icon(Icons.Default.Person, null) }, label = { Text("Профиль") })
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> SearchScreen(vm)
                1 -> PublishScreen(vm) { tab = 2 }
                2 -> MyTripsScreen(vm)
                else -> ProfileScreen()
            }
        }
    }
}

@Composable
private fun Header(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 18.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(subtitle, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CityField(label: String, value: String, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = value, onValueChange = { onChange(it); expanded = true },
            modifier = Modifier.fillMaxWidth().menuAnchor(),
            label = { Text(label) }, singleLine = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            cities.filter { it.contains(value, true) }.forEach { city ->
                DropdownMenuItem(text = { Text(city) }, onClick = { onChange(city); expanded = false })
            }
        }
    }
}

@Composable
private fun SearchScreen(vm: TripViewModel) {
    val from by vm.from.collectAsState()
    val to by vm.to.collectAsState()
    val passengers by vm.passengers.collectAsState()
    val trips by vm.results.collectAsState()
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(top = 26.dp, bottom = 24.dp)) {
        item {
            Header("Попутчик BY", "Найди поездку между Польшей и Беларусью")
            Text("Маршрут", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            CityField("Откуда", from, { vm.from.value = it })
            Spacer(Modifier.height(10.dp))
            CityField("Куда", to, { vm.to.value = it })
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Пассажиры", modifier = Modifier.weight(1f))
                IconButton(onClick = { if (passengers > 1) vm.passengers.value-- }) { Text("−") }
                Text("$passengers", fontWeight = FontWeight.Bold)
                IconButton(onClick = { if (passengers < 8) vm.passengers.value++ }) { Text("+") }
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.Search, null)
                Spacer(Modifier.width(8.dp))
                Text("Найти поездку")
            }
            Spacer(Modifier.height(22.dp))
            Text("Доступные поездки", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
        }
        if (trips.isEmpty()) {
            item {
                EmptyState("Пока нет подходящих поездок", "Измени маршрут или опубликуй свою поездку.")
            }
        } else {
            items(trips, key = { it.id }) { TripCard(it) }
        }
    }
}

@Composable
private fun PublishScreen(vm: TripViewModel, onPublished: () -> Unit) {
    var from by remember { mutableStateOf("Варшава") }
    var to by remember { mutableStateOf("Брест") }
    var date by remember { mutableStateOf(SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date())) }
    var time by remember { mutableStateOf("08:00") }
    var price by remember { mutableStateOf("50") }
    var seats by remember { mutableIntStateOf(3) }
    var driver by remember { mutableStateOf("") }
    var car by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(top = 26.dp, bottom = 30.dp)) {
        item {
            Header("Опубликовать поездку", "Предложи свободные места попутчикам")
            CityField("Откуда", from, { from = it })
            Spacer(Modifier.height(10.dp))
            CityField("Куда", to, { to = it })
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(date, { date = it }, Modifier.fillMaxWidth(), label = { Text("Дата (дд.мм.гггг)") }, singleLine = true)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(time, { time = it }, Modifier.fillMaxWidth(), label = { Text("Время отправления") }, singleLine = true)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(price, { price = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("Цена за место") }, suffix = { Text("PLN / BYN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Свободные места", Modifier.weight(1f))
                IconButton(onClick = { if (seats > 1) seats-- }) { Text("−") }
                Text("$seats", fontWeight = FontWeight.Bold)
                IconButton(onClick = { if (seats < 8) seats++ }) { Text("+") }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(driver, { driver = it }, Modifier.fillMaxWidth(), label = { Text("Имя водителя") }, singleLine = true)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(car, { car = it }, Modifier.fillMaxWidth(), label = { Text("Автомобиль") }, singleLine = true)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("Комментарий (необязательно)") }, minLines = 2)
            if (error.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(error, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    val p = price.toIntOrNull()
                    error = when {
                        from.isBlank() || to.isBlank() -> "Укажи города отправления и прибытия"
                        from.equals(to, true) -> "Города отправления и прибытия должны отличаться"
                        p == null || p < 0 -> "Проверь стоимость поездки"
                        driver.isBlank() -> "Укажи имя водителя"
                        car.isBlank() -> "Укажи автомобиль"
                        else -> ""
                    }
                    if (error.isBlank()) {
                        vm.publish(Trip(fromCity = from, toCity = to, date = date, time = time, price = p!!, seats = seats, driver = driver, car = car, note = note))
                        onPublished()
                    }
                },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
            ) { Text("Опубликовать поездку") }
        }
    }
}

@Composable
private fun MyTripsScreen(vm: TripViewModel) {
    val trips by vm.allTrips.collectAsState()
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(top = 26.dp, bottom = 24.dp)) {
        item { Header("Мои поездки", "Управляй опубликованными поездками") }
        if (trips.isEmpty()) item { EmptyState("Здесь пока пусто", "Опубликованные поездки появятся здесь.") }
        items(trips, key = { it.id }) { trip ->
            Column {
                TripCard(trip)
                TextButton(onClick = { vm.delete(trip.id) }, modifier = Modifier.align(Alignment.End)) {
                    Text("Удалить объявление", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun TripCard(trip: Trip) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${trip.fromCity}  →  ${trip.toCity}", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${trip.price}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            Text("${trip.date} • ${trip.time}  |  ${trip.seats} мест", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Person, null, tint = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.width(6.dp))
                Text("${trip.driver} • ${trip.car}")
            }
            if (trip.note.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(trip.note, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
            }
        }
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.DirectionsCar, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
            Spacer(Modifier.height(8.dp))
            Text(title, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
        }
    }
}

@Composable
private fun ProfileScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Header("Профиль", "Настройки аккаунта")
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Гость", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Локальный профиль для первой версии", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
                Spacer(Modifier.height(14.dp))
                Text("В следующих версиях здесь появятся регистрация по телефону, фото, рейтинг, отзывы и подтверждение личности.")
            }
        }
    }
}
