package by.poputchik.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import by.poputchik.app.data.AppDatabase
import by.poputchik.app.ui.PoputchikApp
import by.poputchik.app.ui.TripViewModel
import by.poputchik.app.ui.TripViewModelFactory
import by.poputchik.app.ui.theme.PoputchikTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDatabase.get(applicationContext).tripDao()
        setContent {
            PoputchikTheme {
                val vm: TripViewModel = viewModel(factory = TripViewModelFactory(dao))
                PoputchikApp(vm)
            }
        }
    }
}
