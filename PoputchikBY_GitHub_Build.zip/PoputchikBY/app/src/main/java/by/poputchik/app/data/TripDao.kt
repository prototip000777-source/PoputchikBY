package by.poputchik.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TripDao {
    @Query("SELECT * FROM trips ORDER BY date, time")
    fun observeAll(): Flow<List<Trip>>

    @Query("SELECT * FROM trips WHERE (:fromCity = '' OR fromCity LIKE '%' || :fromCity || '%') AND (:toCity = '' OR toCity LIKE '%' || :toCity || '%') AND seats >= :passengers ORDER BY date, time")
    fun search(fromCity: String, toCity: String, passengers: Int): Flow<List<Trip>>

    @Insert
    suspend fun insert(trip: Trip)

    @Query("DELETE FROM trips WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT COUNT(*) FROM trips")
    suspend fun count(): Int
}
