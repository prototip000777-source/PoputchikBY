package by.poputchik.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NightColors = darkColorScheme(
    primary = Color(0xFF79D7C3),
    onPrimary = Color(0xFF062A25),
    secondary = Color(0xFF9BB8FF),
    background = Color(0xFF0B1018),
    surface = Color(0xFF151D29),
    surfaceVariant = Color(0xFF202B3A),
    onBackground = Color(0xFFF2F5FA),
    onSurface = Color(0xFFF2F5FA)
)

@Composable
fun PoputchikTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = NightColors, content = content)
}
